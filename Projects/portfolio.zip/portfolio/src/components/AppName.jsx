import React from 'react'
import styles from "./AppName.module.css"

const AppName = () => {
  return (
    <h1 className={styles.todoHeading}>TODO React App</h1>
  )
}

export default AppName
